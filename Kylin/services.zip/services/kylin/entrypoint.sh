#!/bin/bash

nohup $HIVE_HOME/bin/hive --service metastore >> $HIVE_HOME/logs/hivemetastorelog.log 2>&1 &

$SPARK_HOME/sbin/start-master.sh 
$SPARK_HOME/sbin/start-worker.sh spark://kylin:7077

$ZOOKEEPER_HOME/bin/zkServer.sh start

${KYLIN_HOME}/bin/sample.sh

$KYLIN_HOME/bin/kylin.sh start

while :
do
    if [ -d "$KYLIN_HOME/tomcat/webapps/kylin/WEB-INF/lib/" ]; then
        mv commons-collections-3.2.2.jar $KYLIN_HOME/tomcat/webapps/kylin/WEB-INF/lib/
        mv commons-configuration-1.3.jar $KYLIN_HOME/tomcat/webapps/kylin/WEB-INF/lib/
        cp $HADOOP_HOME/share/hadoop/common/lib/aws-java-sdk-bundle-1.11.375.jar $KYLIN_HOME/tomcat/webapps/kylin/WEB-INF/lib/
        cp $HADOOP_HOME/share/hadoop/common/lib/hadoop-aws-3.2.0.jar $KYLIN_HOME/tomcat/webapps/kylin/WEB-INF/lib/
        echo "Libraries added"
        break
    else
        sleep 1
    fi
done


while :
do
    sleep 1
done
